# VR Box AR
1. Bu klasörü GitHub'a yükle (repo kökü).
2. Actions → "Build APK" otomatik çalışır.
3. Çıkan `vrbox-ar-apk` artifact içinden app-debug.apk indir.
